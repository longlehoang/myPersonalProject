select	ol.order_no
		,ol.promotion_id
		,ol.own_pro_id,sum(Quantity_Confirmed) as qtyDiscounted,ol.[UOM_CODE]
			/*,case when ol.[UOM_CODE] = 'CS' then sum(Quantity_Confirmed) else null end as qtyDiscounted_CS
			,case when ol.[UOM_CODE] = 'EA' then sum(Quantity_Confirmed) else null end as qtyDiscounted_EA
			,sum(Quantity_Confirmed_EC) as qtyDiscounted_EC*/
					from order_headers oh  with(index = [IDX_Order_Header_Comfirmed_Date])
					inner join ORDER_lines ol  with(index = [idx_orderNo]) 
						on ol.ORDER_NO=oh.ORDER_NO 
					where ol.FREE_PRODUCTS=2 AND oh.order_no = '7951602091155261'
		group by ol.order_no
		,ol.promotion_id
		,own_pro_id,ol.[UOM_CODE]

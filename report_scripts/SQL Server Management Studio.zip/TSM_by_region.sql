SELECT cast(floor(cast(ls.Date AS float)) AS datetime),po.SalesOffice, po.tsmcode, po.TerritorySalesManager
FROM [dbo].[Log_Sync] ls
JOIN [dbo].[Mas_User] ms ON ls.UserCode = ms.UserCode 
JOIN [CCVN4_Reporting].dbo.View_PositionOrg po ON po.TSMCode = ms.UserCode
WHERE ls.Date > cast(floor(cast(GETDATE() AS float) - 7) AS datetime)
AND ms.GroupCode IN ('TSM')
AND OrgId IN (SELECT ID FROM dbo.Mas_Organization WHERE Code LIKE 'V%')
AND ((DATEPART(dw, ls.Date) + @@DATEFIRST) % 7) NOT IN (1)
GROUP BY cast(floor(cast(ls.Date AS float)) AS datetime), po.SalesOffice, po.tsmcode, po.TerritorySalesManager
ORDER BY cast(floor(cast(ls.Date AS float)) AS datetime);

SELECT cast(floor(cast(ls.Date AS float)) AS datetime),po.SalesOffice, po.AreaCode, po.AreaManager
FROM [dbo].[Log_Sync] ls
JOIN [dbo].[Mas_User] ms ON ls.UserCode = ms.UserCode 
JOIN [CCVN4_Reporting].dbo.View_PositionOrg po ON po.AreaCode = ms.UserCode
WHERE ls.Date > cast(floor(cast(GETDATE() AS float) - 7) AS datetime)
AND ms.GroupCode IN ('ASM')
AND OrgId IN (SELECT ID FROM dbo.Mas_Organization WHERE Code LIKE 'V%')
AND ((DATEPART(dw, ls.Date) + @@DATEFIRST) % 7) NOT IN (1)
GROUP BY cast(floor(cast(ls.Date AS float)) AS datetime), po.SalesOffice, po.AreaCode, po.AreaManager
ORDER BY cast(floor(cast(ls.Date AS float)) AS datetime);
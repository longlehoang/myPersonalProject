SELECT * FROM customers where code = '0070055794'

SELECT * FROM customer_photo WHERE customer_id = 91644 AND visit_id = '849160503110758' ORDER BY photo_date

SELECT * FROM CTS_Result WHERE customer_id = 91644 --AND visit_id = '849160503110758'

SELECT * FROM visits where customer_id = 91644 AND id = 849160503110758
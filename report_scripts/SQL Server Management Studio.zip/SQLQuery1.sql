SELECT * FROM customers WHErE code = '0070281699' --ID IN (262519,262532,262541

SELECT top 10000 * FROM sapCustomerContact c 

JOIN SapRep r ON r.repID = c.PartnerID AND r.partnerType = 'ZD'--repid = '00050325'
WHERE c.partnertype = 'ZR'
AND c.deleteFlag = 0

-- AND customerID IN ('0070241012','0070240990','0070241003')
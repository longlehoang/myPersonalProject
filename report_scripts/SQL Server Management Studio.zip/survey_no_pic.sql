SELECT * FROM Customer_photo WHERE ID = '5956a830-12c6-4f7f-91ac-52d51ac28cf4'

SELECT * FROM Customer_photo WHERE MeasureItemID = 258

SELECT * FROM Biz_MeasureGroupDEtail WHERE ItemID = 280-- = 79
SELECT * FROM Biz_MeasureGroup WHERE ID = 48

SELECT * FROM Biz_MeasureItem WHERE ID IN (258,260,280)